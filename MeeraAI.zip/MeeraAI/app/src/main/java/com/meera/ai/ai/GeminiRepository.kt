package com.meera.ai.ai

import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.meera.ai.data.AppLanguage
import com.meera.ai.data.ChatMode
import com.meera.ai.data.DEFAULT_MODEL
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

enum class AiErrorKind { NotConfigured, Network, Quota, AppCheck, ServiceDisabled, Blocked, Other }

sealed interface AiResult {
    data class Success(val text: String) : AiResult
    data class Failure(val kind: AiErrorKind, val message: String) : AiResult
}

class GeminiRepository {
    private val chats = mutableMapOf<String, Chat>()

    private fun model(name: String, system: String) =
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = name.trim().ifBlank { DEFAULT_MODEL },
            systemInstruction = content { text(system) },
        )

    private fun systemPrompt(mode: ChatMode, lang: AppLanguage): String = when (mode) {
        ChatMode.Chat ->
            "You are Meera, a friendly assistant inside the Meera AI Android app. " +
                "Reply in ${lang.label} (${lang.native}). Keep answers short and conversational unless asked for detail. " +
                "Do not claim you can control the phone or other apps yourself; the app handles commands like " +
                "'open YouTube' separately. Use plain text; use fenced code blocks only for code."
        ChatMode.Code ->
            "You are Meera's coding assistant. Supported languages: Python, JavaScript, HTML, CSS, Kotlin. " +
                "Each user message starts with [Language: X]; answer in that language. " +
                "Explain in ${lang.label} (${lang.native}), but keep code and code comments in English. " +
                "Put all code in fenced blocks with a language tag. Be concise and correct."
    }

    suspend fun send(prompt: String, mode: ChatMode, lang: AppLanguage, modelName: String): AiResult {
        if (!FirebaseSetup.configured) {
            return AiResult.Failure(
                AiErrorKind.NotConfigured,
                "Firebase isn't set up yet, so Gemini is unavailable. Add google-services.json (see Settings → AI connection and the README).",
            )
        }
        return try {
            val key = "${mode.name}|${lang.code}|$modelName"
            val chat = chats.getOrPut(key) { model(modelName, systemPrompt(mode, lang)).startChat() }
            val text = chat.sendMessage(prompt).text
            if (text.isNullOrBlank()) {
                AiResult.Failure(AiErrorKind.Blocked, "Gemini returned no text (the reply may have been blocked by safety filters). Try rephrasing.")
            } else AiResult.Success(text.trim())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            classify(e)
        }
    }

    suspend fun ping(modelName: String): AiResult {
        if (!FirebaseSetup.configured) return AiResult.Failure(AiErrorKind.NotConfigured, FirebaseSetup.detail)
        return try {
            val t = model(modelName, "You are a connectivity test.").generateContent("Reply with the word OK.").text
            if (t.isNullOrBlank()) AiResult.Failure(AiErrorKind.Other, "Empty response") else AiResult.Success(t.trim())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            classify(e)
        }
    }

    fun reset(mode: ChatMode) {
        chats.keys.removeAll { it.startsWith("${mode.name}|") }
    }

    private fun classify(e: Exception): AiResult.Failure {
        val chain = generateSequence<Throwable>(e) { it.cause }.take(6).toList()
        val names = chain.joinToString(" ") { it.javaClass.simpleName }
        val msg = chain.joinToString(" ") { it.message.orEmpty() }.lowercase()
        fun f(k: AiErrorKind, m: String) = AiResult.Failure(k, m)
        return when {
            names.contains("QuotaExceeded") || "quota" in msg || "429" in msg || "resource_exhausted" in msg ->
                f(AiErrorKind.Quota, "Gemini's usage quota or rate limit was reached. Wait a minute and retry, or check your quota in the Firebase console.")
            chain.any { it is IOException } || names.contains("RequestTimeout") ->
                f(AiErrorKind.Network, "Couldn't reach Gemini. Check your internet connection and try again.")
            "app check" in msg || "appcheck" in msg || names.contains("AppCheck") ->
                f(AiErrorKind.AppCheck, "App Check rejected the request. For debug builds, register the App Check debug token in the Firebase console (see README).")
            names.contains("ServiceDisabled") || names.contains("APINotConfigured") || "has not been used" in msg || "not enabled" in msg ->
                f(AiErrorKind.ServiceDisabled, "Firebase AI Logic isn't enabled for this project. Enable it in the Firebase console (Build → AI Logic).")
            names.contains("PromptBlocked") || names.contains("ContentBlocked") || names.contains("ResponseStopped") ->
                f(AiErrorKind.Blocked, "Gemini declined to answer that request. Try rephrasing.")
            names.contains("UnsupportedUserLocation") ->
                f(AiErrorKind.Other, "Gemini isn't available in your region.")
            else -> f(AiErrorKind.Other, "Something went wrong: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
