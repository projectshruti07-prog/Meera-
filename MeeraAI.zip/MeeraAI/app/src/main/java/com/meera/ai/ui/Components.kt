package com.meera.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.meera.ai.MeeraViewModel
import com.meera.ai.data.ChatMessage
import com.meera.ai.data.OrbState
import com.meera.ai.data.UiText
import kotlinx.coroutines.delay

@Composable
fun NeonBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Neon.Bg)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.radialGradient(listOf(Neon.Pink.copy(alpha = 0.18f), Color.Transparent), Offset.Zero, size.maxDimension * 0.7f))
            drawRect(Brush.radialGradient(listOf(Neon.Cyan.copy(alpha = 0.14f), Color.Transparent), Offset(size.width, size.height), size.maxDimension * 0.7f))
        }
        content()
    }
}

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(Neon.Surface.copy(alpha = 0.85f))
            .border(1.dp, Brush.linearGradient(listOf(Neon.Pink.copy(alpha = 0.5f), Neon.Cyan.copy(alpha = 0.5f))), shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

fun stateLabel(ui: UiText, s: OrbState) = when (s) {
    OrbState.Idle -> ui.stateIdle
    OrbState.Listening -> ui.stateListening
    OrbState.Thinking -> ui.stateThinking
    OrbState.Speaking -> ui.stateSpeaking
}

// ---------- message rendering ----------
sealed interface Segment {
    data class Prose(val text: String) : Segment
    data class Code(val lang: String, val code: String) : Segment
}

fun parseSegments(src: String): List<Segment> {
    val out = mutableListOf<Segment>()
    src.split("```").forEachIndexed { i, p ->
        if (i % 2 == 0) {
            if (p.isNotBlank()) out += Segment.Prose(p.trim())
        } else {
            val nl = p.indexOf('\n')
            val lang = if (nl >= 0) p.substring(0, nl).trim() else ""
            val body = if (nl >= 0) p.substring(nl + 1) else p
            out += Segment.Code(lang, body.trimEnd())
        }
    }
    return out
}

@Composable
fun CodeBlock(lang: String, code: String, ui: UiText) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color(0xFF0B0716)).border(1.dp, Neon.Cyan.copy(alpha = 0.35f), shape)) {
        Row(Modifier.fillMaxWidth().background(Neon.SurfaceHi).padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifBlank { "code" }, color = Neon.Cyan, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)); copied = true }) {
                Icon(if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy, null, Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (copied) ui.copied else ui.copy)
            }
        }
        Box(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
            Text(code, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFE7E1FF), softWrap = false)
        }
    }
}

@Composable
fun MessageBubble(msg: ChatMessage, ui: UiText, onRetry: (() -> Unit)?) {
    val shape = RoundedCornerShape(18.dp)
    val bg = when {
        msg.fromUser -> Neon.Purple.copy(alpha = 0.35f)
        msg.isError -> Neon.Error.copy(alpha = 0.18f)
        else -> Neon.Surface
    }
    val border = if (msg.isError) Neon.Error.copy(alpha = 0.6f) else Neon.Purple.copy(alpha = 0.4f)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 340.dp).clip(shape).background(bg).border(1.dp, border, shape).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    parseSegments(msg.text).forEach { seg ->
                        when (seg) {
                            is Segment.Prose -> Text(seg.text, color = if (msg.isError) Neon.Error else Neon.Text, style = MaterialTheme.typography.bodyLarge)
                            is Segment.Code -> CodeBlock(seg.lang, seg.code, ui)
                        }
                    }
                }
            }
            if (msg.isError && onRetry != null) {
                TextButton(onClick = onRetry) {
                    Icon(Icons.Rounded.Refresh, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(ui.retry)
                }
            }
        }
    }
}

@Composable
fun ThinkingRow(label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CircularProgressIndicator(Modifier.size(18.dp), color = Neon.Cyan, strokeWidth = 2.dp)
        Text(label, color = Neon.Muted)
    }
}

@Composable
fun ChatInputBar(
    hint: String,
    ui: UiText,
    listening: Boolean,
    enabled: Boolean,
    onSend: (String) -> Unit,
    onMic: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    var text by rememberSaveable { mutableStateOf("") }
    fun send() { if (text.isNotBlank() && enabled) { onSend(text); text = "" } }
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
            placeholder = { Text(hint, maxLines = 1) }, shape = RoundedCornerShape(28.dp), maxLines = 4,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Neon.Cyan, unfocusedBorderColor = Neon.Purple.copy(alpha = 0.5f),
                focusedContainerColor = Neon.Surface, unfocusedContainerColor = Neon.Surface,
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() }),
        )
        if (onMic != null) {
            FilledIconButton(
                onClick = onMic,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (listening) Neon.Pink else Neon.SurfaceHi, contentColor = Neon.Text),
            ) { Icon(Icons.Rounded.Mic, if (listening) ui.tapToStop else ui.tapToSpeak) }
        }
        FilledIconButton(
            onClick = { send() }, enabled = enabled && text.isNotBlank(),
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Neon.Cyan, contentColor = Color(0xFF00212A)),
        ) { Icon(Icons.AutoMirrored.Rounded.Send, ui.send) }
    }
}

@Composable
fun MicDeniedBanner(vm: MeeraViewModel) {
    val ctx = LocalContext.current
    NeonCard {
        Text(vm.ui.micDeniedMsg, color = Neon.Text)
        OutlinedButton(onClick = {
            ctx.startActivity(
                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }) { Text(vm.ui.openAppSettings) }
    }
}

/** Asks for the microphone permission only when the user taps the mic. */
@Composable
fun rememberMicAction(vm: MeeraViewModel): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startListening() else vm.onMicDenied()
    }
    return {
        when {
            vm.orbState == OrbState.Listening -> vm.stopListening()
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED -> vm.startListening()
            else -> launcher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}
