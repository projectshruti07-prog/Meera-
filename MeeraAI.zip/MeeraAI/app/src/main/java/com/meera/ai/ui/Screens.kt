package com.meera.ai.ui

import android.content.pm.ApplicationInfo
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.MeeraViewModel
import com.meera.ai.ai.FirebaseSetup
import com.meera.ai.data.*

@Composable
private fun QuickAction(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(Neon.Surface.copy(alpha = 0.9f))
            .clickable(onClick = onClick).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = Neon.Cyan)
        Text(label, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge, maxLines = 2)
    }
}

// ================= HOME =================
@Composable
fun HomeScreen(vm: MeeraViewModel, onNavigate: (Dest) -> Unit) {
    val ui = vm.ui
    val mic = rememberMicAction(vm)
    val last = vm.chat.lastOrNull { !it.fromUser }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(8.dp))
            Text("MEERA AI", color = Neon.Cyan, style = MaterialTheme.typography.labelLarge, letterSpacing = 4.sp)
            Text(ui.greeting, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
            AiOrb(vm.orbState, Modifier.size(240.dp))
            Crossfade(vm.orbState, label = "state") { Text(stateLabel(ui, it), color = Neon.Muted) }
            if (vm.partialSpeech.isNotBlank()) Text("“${vm.partialSpeech}”", color = Neon.Cyan, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            if (vm.micDenied) { MicDeniedBanner(vm); Spacer(Modifier.height(12.dp)) }
            if (last != null) {
                NeonCard(Modifier.fillMaxWidth()) {
                    Text(last.text, maxLines = 5, color = if (last.isError) Neon.Error else Neon.Text)
                    TextButton(onClick = { onNavigate(Dest.Chat) }) { Text(ui.openChat) }
                }
                Spacer(Modifier.height(12.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickAction(Icons.Rounded.PlayCircle, ui.qaYoutube, Modifier.weight(1f)) { vm.openYoutubeNow() }
                QuickAction(Icons.Rounded.Apps, ui.qaApps, Modifier.weight(1f)) { vm.openAppPicker() }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickAction(Icons.Rounded.Code, ui.qaCoding, Modifier.weight(1f)) { onNavigate(Dest.Code) }
                QuickAction(Icons.Rounded.Settings, ui.qaSettings, Modifier.weight(1f)) { onNavigate(Dest.Settings) }
            }
            Spacer(Modifier.height(8.dp))
        }
        ChatInputBar(ui.askHint, ui, vm.orbState == OrbState.Listening, vm.orbState != OrbState.Thinking, { vm.submit(it) }, mic)
    }
}

// ================= CHAT =================
@Composable
fun ChatScreen(vm: MeeraViewModel) {
    val ui = vm.ui
    val mic = rememberMicAction(vm)
    val listState = rememberLazyListState()
    LaunchedEffect(vm.chat.size, vm.orbState) { if (vm.chat.isNotEmpty()) listState.animateScrollToItem(vm.chat.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ui.navChat, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (vm.orbState == OrbState.Speaking) IconButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Rounded.Stop, ui.stopSpeaking, tint = Neon.Pink) }
            if (vm.chat.isNotEmpty()) IconButton(onClick = { vm.clear(ChatMode.Chat) }) { Icon(Icons.Rounded.DeleteSweep, ui.clear) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.chat.isEmpty()) {
                EmptyState(ui.emptyChatTitle, ui.emptyChatBody, listOf("Tell me a fun fact", "Explain how rainbows form", "Play lofi beats on YouTube")) { vm.submit(it) }
            } else {
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(vm.chat, key = { it.id }) { m -> MessageBubble(m, ui, if (m.isError && m == vm.chat.last()) ({ vm.retry(ChatMode.Chat) }) else null) }
                    if (vm.orbState == OrbState.Thinking) item { ThinkingRow(ui.stateThinking) }
                }
            }
        }
        if (vm.micDenied) { MicDeniedBanner(vm) }
        ChatInputBar(ui.askHint, ui, vm.orbState == OrbState.Listening, vm.orbState != OrbState.Thinking, { vm.submit(it) }, mic)
    }
}

@Composable
private fun EmptyState(title: String, body: String, suggestions: List<String>, onPick: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        AiOrb(OrbState.Idle, Modifier.size(140.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, color = Neon.Muted, modifier = Modifier.padding(vertical = 6.dp))
        suggestions.forEach { s ->
            AssistChip(onClick = { onPick(s) }, label = { Text(s) }, modifier = Modifier.padding(vertical = 2.dp),
                colors = AssistChipDefaults.assistChipColors(labelColor = Neon.Text, containerColor = Neon.Surface),
                border = AssistChipDefaults.assistChipBorder(true, borderColor = Neon.Purple.copy(alpha = 0.6f)))
        }
    }
}

// ================= VOICE =================
@Composable
fun VoiceScreen(vm: MeeraViewModel) {
    val ui = vm.ui
    val mic = rememberMicAction(vm)
    val last = vm.chat.lastOrNull { !it.fromUser }
    val listening = vm.orbState == OrbState.Listening
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            AiOrb(vm.orbState, Modifier.size(280.dp))
            Crossfade(vm.orbState, label = "vstate") { Text(stateLabel(ui, it), style = MaterialTheme.typography.titleMedium) }
            if (vm.partialSpeech.isNotBlank()) Text("“${vm.partialSpeech}”", color = Neon.Cyan, modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            if (vm.micDenied) MicDeniedBanner(vm)
            else if (last != null) NeonCard(Modifier.fillMaxWidth()) { Text(last.text, maxLines = 8, color = if (last.isError) Neon.Error else Neon.Text) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            if (vm.orbState == OrbState.Speaking) OutlinedButton(onClick = { vm.stopSpeaking() }) {
                Icon(Icons.Rounded.Stop, null); Spacer(Modifier.width(6.dp)); Text(ui.stopSpeaking)
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(if (listening) Neon.Pink else Neon.Cyan).clickable(onClick = mic),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Mic, if (listening) ui.tapToStop else ui.tapToSpeak, tint = Color(0xFF00212A), modifier = Modifier.size(32.dp)) }
        }
        Text(if (listening) ui.tapToStop else ui.tapToSpeak, color = Neon.Muted, modifier = Modifier.padding(top = 6.dp))
        // text fallback
        ChatInputBar(ui.askHint, ui, listening, vm.orbState != OrbState.Thinking, { vm.submit(it) }, null)
    }
}

// ================= CODING =================
private val codeLangs = listOf("Python", "JavaScript", "HTML", "CSS", "Kotlin")

@Composable
fun CodingScreen(vm: MeeraViewModel) {
    val ui = vm.ui
    val listState = rememberLazyListState()
    LaunchedEffect(vm.code.size, vm.orbState) { if (vm.code.isNotEmpty()) listState.animateScrollToItem(vm.code.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(ui.codeTitle, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (vm.code.isNotEmpty()) IconButton(onClick = { vm.clear(ChatMode.Code) }) { Icon(Icons.Rounded.DeleteSweep, ui.clear) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            codeLangs.forEach { l ->
                FilterChip(
                    selected = vm.codeLanguage == l, onClick = { vm.codeLanguage = l }, label = { Text(l) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Neon.Purple.copy(alpha = 0.45f), selectedLabelColor = Neon.Text),
                )
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.code.isEmpty()) {
                val l = vm.codeLanguage
                EmptyState(ui.codeTitle, "Ask for explanations or code examples in $l:", listOf("Explain closures in $l", "Show a $l example that reads a file", "How do I reverse a list in $l?")) { vm.askCode(it) }
            } else {
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(vm.code, key = { it.id }) { m -> MessageBubble(m, ui, if (m.isError && m == vm.code.last()) ({ vm.retry(ChatMode.Code) }) else null) }
                    if (vm.orbState == OrbState.Thinking) item { ThinkingRow(ui.stateThinking) }
                }
            }
        }
        ChatInputBar(ui.codeHint, ui, false, vm.orbState != OrbState.Thinking, { vm.askCode(it) }, null)
    }
}

// ================= SETTINGS =================
@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    NeonCard(Modifier.fillMaxWidth()) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = Neon.Cyan)
        content()
    }
}

@Composable
fun SettingsScreen(vm: MeeraViewModel) {
    val ui = vm.ui
    val s = vm.settings
    val ctx = LocalContext.current
    val debuggable = (ctx.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(ui.settingsTitle, style = MaterialTheme.typography.headlineSmall)

        Section(ui.aiSection) {
            val (txt, col) = when {
                !FirebaseSetup.configured -> "Not configured — ${FirebaseSetup.detail}" to Neon.Error
                vm.aiStatus is AiStatus.Connected -> ui.connected to Neon.Ok
                vm.aiStatus is AiStatus.Checking -> "…" to Neon.Muted
                vm.aiStatus is AiStatus.Failed -> (vm.aiStatus as AiStatus.Failed).message to Neon.Error
                else -> "${FirebaseSetup.detail}. Not tested yet." to Neon.Muted
            }
            Text("${ui.connection}: $txt", color = col)
            Text("Backend: Gemini Developer API via Firebase AI Logic (no API key in the app).", color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
            Text("App Check: ${if (debuggable) "debug provider" else "Play Integrity"}", color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = s.modelName, onValueChange = { vm.update(s.copy(modelName = it)) }, label = { Text("Gemini model name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.testConnection() }, enabled = vm.aiStatus !is AiStatus.Checking) { Text(ui.testConnection) }
        }

        Section(ui.langSection) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.forEach { l ->
                    FilterChip(
                        selected = s.language == l, onClick = { vm.update(s.copy(language = l)) }, label = { Text(l.native) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Neon.Purple.copy(alpha = 0.45f), selectedLabelColor = Neon.Text),
                    )
                }
            }
            Text("Sets the UI language, Gemini's reply language, speech recognition and the spoken voice.", color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
        }

        Section(ui.speechSection) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ui.speakReplies, Modifier.weight(1f))
                Switch(checked = s.speakReplies, onCheckedChange = { vm.update(s.copy(speakReplies = it)) })
            }
            Text("${ui.speechRate}: ${"%.1f".format(s.speechRate)}×")
            Slider(value = s.speechRate, onValueChange = { vm.update(s.copy(speechRate = it)) }, valueRange = 0.5f..1.5f)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { vm.testVoice() }) { Text(ui.testVoice) }
                OutlinedButton(onClick = { vm.stopSpeaking() }) { Text(ui.stopSpeaking) }
            }
        }

        Section(ui.aboutTitle) {
            Text(
                "• Can: open YouTube, search YouTube, open installed apps (with confirmation for typed/spoken commands).\n" +
                    "• Cannot: tap buttons inside other apps, read other apps' screens, send messages or make calls. Android doesn't allow that without special accessibility permissions, which Meera doesn't use.\n" +
                    "• Voice commands are English-only; chatting works in all three languages.\n" +
                    "• Voice quality depends on the speech and Text-to-speech engines installed on your phone.",
                style = MaterialTheme.typography.bodyMedium, color = Neon.Muted,
            )
        }
    }
}
