package com.meera.ai.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.meera.ai.MeeraViewModel
import com.meera.ai.data.UiText

enum class Dest(val route: String, val icon: ImageVector) {
    Home("home", Icons.Rounded.Home),
    Chat("chat", Icons.Rounded.ChatBubble),
    Voice("voice", Icons.Rounded.GraphicEq),
    Code("code", Icons.Rounded.Code),
    Settings("settings", Icons.Rounded.Settings);

    fun label(ui: UiText) = when (this) {
        Home -> ui.navHome; Chat -> ui.navChat; Voice -> ui.navVoice; Code -> ui.navCode; Settings -> ui.navSettings
    }
}

@Composable
fun MeeraRoot() {
    val vm: MeeraViewModel = viewModel()
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val ui = vm.ui
    LaunchedEffect(Unit) { vm.events.collect { snack.showSnackbar(it) } }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route

    fun go(d: Dest) = nav.navigate(d.route) {
        popUpTo(Dest.Home.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    NeonBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar(containerColor = Neon.Surface.copy(alpha = 0.94f)) {
                    Dest.entries.forEach { d ->
                        NavigationBarItem(
                            selected = current == d.route, onClick = { go(d) },
                            icon = { Icon(d.icon, d.label(ui)) },
                            label = { Text(d.label(ui), maxLines = 1, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Neon.Purple.copy(alpha = 0.4f), selectedIconColor = Neon.Cyan,
                                selectedTextColor = Neon.Cyan, unselectedIconColor = Neon.Muted, unselectedTextColor = Neon.Muted,
                            ),
                        )
                    }
                }
            },
        ) { inner ->
            NavHost(
                nav, startDestination = Dest.Home.route,
                modifier = Modifier.padding(inner).consumeWindowInsets(inner).imePadding(),
                enterTransition = { fadeIn(tween(350)) + slideInHorizontally(tween(350)) { it / 12 } },
                exitTransition = { fadeOut(tween(200)) },
                popEnterTransition = { fadeIn(tween(350)) },
                popExitTransition = { fadeOut(tween(200)) },
            ) {
                composable(Dest.Home.route) { HomeScreen(vm) { go(it) } }
                composable(Dest.Chat.route) { ChatScreen(vm) }
                composable(Dest.Voice.route) { VoiceScreen(vm) }
                composable(Dest.Code.route) { CodingScreen(vm) }
                composable(Dest.Settings.route) { SettingsScreen(vm) }
            }
        }
    }

    // Confirmation for typed/spoken commands
    vm.pending?.let { cmd ->
        AlertDialog(
            onDismissRequest = { vm.cancelPending() },
            containerColor = Neon.SurfaceHi,
            title = { Text(ui.confirmTitle) },
            text = { Text("${cmd.description}?") },
            confirmButton = { TextButton(onClick = { vm.confirmPending() }) { Text(ui.confirmYes) } },
            dismissButton = { TextButton(onClick = { vm.cancelPending() }) { Text(ui.confirmNo) } },
        )
    }

    if (vm.showAppPicker) AppPickerDialog(vm, ui)
}

@Composable
private fun AppPickerDialog(vm: MeeraViewModel, ui: UiText) {
    var query by remember { mutableStateOf("") }
    val all = vm.apps
    AlertDialog(
        onDismissRequest = { vm.closeAppPicker() },
        containerColor = Neon.SurfaceHi,
        title = { Text(ui.chooseApp) },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text(ui.searchApps) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                when {
                    all == null -> CircularProgressIndicator(color = Neon.Cyan)
                    else -> {
                        val shown = all.filter { it.label.contains(query, true) }
                        if (shown.isEmpty()) Text("No apps found.", color = Neon.Muted)
                        LazyColumn(Modifier.heightIn(max = 340.dp)) {
                            items(shown, key = { it.packageName }) { app ->
                                Text(app.label, Modifier.fillMaxWidth().clickable { vm.launchFromPicker(app) }.padding(vertical = 12.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.closeAppPicker() }) { Text(ui.confirmNo) } },
    )
}
