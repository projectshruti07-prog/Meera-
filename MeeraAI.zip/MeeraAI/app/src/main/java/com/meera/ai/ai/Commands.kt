package com.meera.ai.ai

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

data class AppInfo(val label: String, val packageName: String)

sealed interface AppCommand {
    val description: String

    data object OpenYoutube : AppCommand { override val description = "Open YouTube" }
    data class SearchYoutube(val query: String) : AppCommand { override val description = "Search YouTube for “$query”" }
    data class OpenApp(val name: String) : AppCommand { override val description = "Open the app “$name”" }
}

/** Understands simple commands in English, Hindi, Bengali and romanized Hindi (Hinglish). Everything else goes to Gemini. */
object CommandParser {
    private const val YT = "(?:youtube|you tube|यूट्यूब|यूटयूब|ইউটিউব)"
    private const val OPEN = "(?:open|launch|खोलो|खोलिए|खोलें|खोल|kholo|kholiye|khol|খোলো|খুলুন|খোল)"
    private const val PLAY = "(?:play|search|chalao|chala|चलाओ|चला|सुनाओ|खोजो|सर्च\\s*करो|search\\s*karo|চালাও|চালান|খোঁজো|শোনাও)"
    private const val PAR = "(?:on|in|par|pe|पर|में|এ|তে)"
    private const val END = "[.!।]?$"
    private val I = RegexOption.IGNORE_CASE

    private val openYt = listOf(
        Regex("^(?:please\\s+)?$OPEN\\s+$YT$END", I),
        Regex("^(?:please\\s+)?$YT\\s+$OPEN$END", I),
    )
    private val ytSearch = listOf(
        Regex("^(?:please\\s+)?(?:play|search|find|watch)\\s+(.+?)\\s+$PAR\\s+$YT$END", I),
        Regex("^(?:please\\s+)?$YT\\s+$PAR\\s+(.+?)\\s+$PLAY$END", I),
        Regex("^(?:please\\s+)?(.+?)\\s+$YT\\s+$PAR\\s+$PLAY$END", I),
        Regex("^(?:please\\s+)?(?:search\\s+$YT\\s+for|$YT\\s+search(?:\\s+for)?|$YT)\\s+(.+?)$END", I),
    )
    private val openApp = listOf(
        Regex("^(?:please\\s+)?(?:open|launch)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$END", I),
        Regex("^(?:please\\s+)?(.+?)\\s+(?:app\\s+)?$OPEN$END", I),
    )

    fun parse(input: String): AppCommand? {
        val t = input.trim()
        if (openYt.any { it.matches(t) }) return AppCommand.OpenYoutube
        for (r in ytSearch) r.find(t)?.let { return AppCommand.SearchYoutube(it.groupValues[1].trim()) }
        for (r in openApp) r.find(t)?.let { return AppCommand.OpenApp(it.groupValues[1].trim()) }
        return null
    }
}

object AndroidActions {
    @Suppress("DEPRECATION")
    fun launchableApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else pm.queryIntentActivities(intent, 0)
        return list.map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != ctx.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun findApp(ctx: Context, name: String): AppInfo? {
        val apps = launchableApps(ctx)
        return apps.firstOrNull { it.label.equals(name, true) } ?: apps.firstOrNull { it.label.contains(name, true) }
    }

    fun launchApp(ctx: Context, pkg: String): Boolean = try {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (i == null) false else { ctx.startActivity(i); true }
    } catch (e: Exception) { false }

    fun openUrl(ctx: Context, url: String): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    fun openYoutube(ctx: Context): Boolean = launchApp(ctx, "com.google.android.youtube") || openUrl(ctx, "https://www.youtube.com")

    fun searchYoutube(ctx: Context, query: String): Boolean {
        val intent = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube")
            .putExtra("query", query).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent); true
        } catch (e: ActivityNotFoundException) {
            openUrl(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(query))
        } catch (e: Exception) { false }
    }
}

fun AppCommand.run(ctx: Context): String = when (this) {
    AppCommand.OpenYoutube ->
        if (AndroidActions.openYoutube(ctx)) "Opened YouTube." else "I couldn't open YouTube on this device."
    is AppCommand.SearchYoutube ->
        if (AndroidActions.searchYoutube(ctx, query)) "Searching YouTube for “$query”." else "I couldn't open YouTube search."
    is AppCommand.OpenApp -> {
        val app = AndroidActions.findApp(ctx, name)
        when {
            app == null -> "I couldn't find an installed app named “$name”."
            AndroidActions.launchApp(ctx, app.packageName) -> "Opened ${app.label}."
            else -> "I couldn't open ${app.label}."
        }
    }
}
