package com.meera.ai.ai

import android.content.Context
import com.google.firebase.FirebaseApp

/** Initialises Firebase + App Check only if the developer supplied google-services.json. */
object FirebaseSetup {
    @Volatile
    var configured = false
        private set
    var detail: String = "google-services.json not found. See README → Firebase setup."
        private set

    fun init(ctx: Context) {
        try {
            val app = FirebaseApp.getApps(ctx).firstOrNull() ?: FirebaseApp.initializeApp(ctx)
            if (app == null) return
            AppCheckInstaller.install()
            configured = true
            detail = "Firebase project: ${app.options.projectId}"
        } catch (e: Exception) {
            detail = "Firebase failed to start: ${e.message}"
        }
    }
}
