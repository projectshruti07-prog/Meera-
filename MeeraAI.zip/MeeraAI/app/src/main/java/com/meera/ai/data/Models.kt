package com.meera.ai.data

import java.util.Locale

const val DEFAULT_MODEL = "gemini-2.5-flash"

enum class AppLanguage(val code: String, val label: String, val native: String, val locale: Locale) {
    English("en", "English", "English", Locale.US),
    Bengali("bn", "Bengali", "বাংলা", Locale.forLanguageTag("bn-BD")),
    Hindi("hi", "Hindi", "हिन्दी", Locale.forLanguageTag("hi-IN"));

    val speechTag: String get() = locale.toLanguageTag()
}

enum class OrbState { Idle, Listening, Thinking, Speaking }
enum class ChatMode { Chat, Code }

data class ChatMessage(
    val id: Long,
    val text: String,
    val fromUser: Boolean,
    val isError: Boolean = false,
)

data class Settings(
    val language: AppLanguage = AppLanguage.English,
    val speakReplies: Boolean = true,
    val speechRate: Float = 1f,
    val modelName: String = DEFAULT_MODEL,
)

sealed interface AiStatus {
    data object Unknown : AiStatus
    data object Checking : AiStatus
    data object Connected : AiStatus
    data class Failed(val message: String) : AiStatus
}
