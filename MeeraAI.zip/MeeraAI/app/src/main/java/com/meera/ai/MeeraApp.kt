package com.meera.ai

import android.app.Application
import com.meera.ai.ai.FirebaseSetup

class MeeraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseSetup.init(this)
    }
}
