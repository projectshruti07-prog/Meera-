package com.meera.ai

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.meera.ai.ai.*
import com.meera.ai.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MeeraViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val repo = GeminiRepository()
    private val speech = SpeechController(app)

    var settings by mutableStateOf(store.load()); private set
    val ui: UiText get() = L10n.of(settings.language)

    val chat = mutableStateListOf<ChatMessage>()
    val code = mutableStateListOf<ChatMessage>()

    var orbState by mutableStateOf(OrbState.Idle); private set
    var partialSpeech by mutableStateOf(""); private set
    var micDenied by mutableStateOf(false); private set
    var aiStatus by mutableStateOf<AiStatus>(AiStatus.Unknown); private set
    var pending by mutableStateOf<AppCommand?>(null); private set
    var showAppPicker by mutableStateOf(false); private set
    var apps by mutableStateOf<List<AppInfo>?>(null); private set
    var codeLanguage by mutableStateOf("Python")

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()

    private var nextId = 0L
    private var thinking = false
    private var listening = false
    private var speaking = false
    private var lastRequest: Triple<String, ChatMode, Boolean>? = null

    init {
        speech.onSpeaking = { speaking = it; refreshOrb() }
    }

    private fun msg(text: String, fromUser: Boolean, error: Boolean = false) =
        ChatMessage(nextId++, text, fromUser, error)

    private fun refreshOrb() {
        orbState = when {
            listening -> OrbState.Listening
            thinking -> OrbState.Thinking
            speaking -> OrbState.Speaking
            else -> OrbState.Idle
        }
    }

    private fun toast(s: String) { _events.tryEmit(s) }

    fun update(s: Settings) { settings = s; store.save(s) }

    // ---------- chat ----------
    fun submit(text: String, spoken: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        chat += msg(t, true)
        val cmd = CommandParser.parse(t)
        if (cmd != null) {
            val resolvable = cmd !is AppCommand.OpenApp || AndroidActions.findApp(getApplication(), cmd.name) != null
            if (resolvable) {
                // Commands typed or spoken (possibly misheard) always need explicit confirmation.
                pending = cmd
                chat += msg("${cmd.description}? Please confirm.", false)
                return
            }
        }
        askAi(t, ChatMode.Chat, spoken)
    }

    fun askCode(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        code += msg(t, true)
        askAi("[Language: $codeLanguage]\n$t", ChatMode.Code, false)
    }

    private fun askAi(prompt: String, mode: ChatMode, spoken: Boolean) {
        val list = if (mode == ChatMode.Chat) chat else code
        lastRequest = Triple(prompt, mode, spoken)
        thinking = true; refreshOrb()
        viewModelScope.launch {
            when (val r = repo.send(prompt, mode, settings.language, settings.modelName)) {
                is AiResult.Success -> {
                    list += msg(r.text, false)
                    if (mode == ChatMode.Chat && (spoken || settings.speakReplies)) speakText(r.text)
                }
                is AiResult.Failure -> list += msg(r.message, false, error = true)
            }
            thinking = false; refreshOrb()
        }
    }

    fun retry(mode: ChatMode) {
        val list = if (mode == ChatMode.Chat) chat else code
        val last = lastRequest ?: return
        if (thinking || last.second != mode) return
        if (list.lastOrNull()?.isError == true) list.removeAt(list.lastIndex)
        askAi(last.first, last.second, last.third)
    }

    fun clear(mode: ChatMode) {
        if (mode == ChatMode.Chat) chat.clear() else code.clear()
        repo.reset(mode)
    }

    // ---------- commands ----------
    fun confirmPending() {
        val cmd = pending ?: return
        pending = null
        chat += msg(cmd.run(getApplication()), false)
    }

    fun cancelPending() {
        if (pending != null) chat += msg("Okay, cancelled.", false)
        pending = null
    }

    fun openYoutubeNow() {
        if (!AndroidActions.openYoutube(getApplication())) toast("Couldn't open YouTube.")
    }

    fun openAppPicker() {
        showAppPicker = true
        if (apps == null) viewModelScope.launch {
            apps = withContext(Dispatchers.Default) { AndroidActions.launchableApps(getApplication()) }
        }
    }

    fun closeAppPicker() { showAppPicker = false }

    /** The user explicitly tapped this app in the list, so no extra confirmation is needed. */
    fun launchFromPicker(app: AppInfo) {
        showAppPicker = false
        if (!AndroidActions.launchApp(getApplication(), app.packageName)) toast("Couldn't open ${app.label}.")
    }

    // ---------- voice ----------
    fun startListening() {
        if (thinking) return
        micDenied = false
        stopSpeaking()
        listening = true; partialSpeech = ""; refreshOrb()
        speech.startListening(
            settings.language,
            onPartial = { partialSpeech = it },
            onResult = { listening = false; partialSpeech = ""; refreshOrb(); submit(it, spoken = true) },
            whenError = { listening = false; partialSpeech = ""; refreshOrb(); toast(it) },
        )
    }

    fun stopListening() = speech.stopListening()
    fun onMicDenied() { micDenied = true }
    fun stopSpeaking() = speech.stopSpeaking()

    private fun speakText(text: String) {
        speech.speak(text, settings.language, settings.speechRate)?.let { toast(it) }
    }

    fun testVoice() { speakText(ui.greeting) }

    // ---------- AI status ----------
    fun testConnection() {
        aiStatus = AiStatus.Checking
        viewModelScope.launch {
            aiStatus = when (val r = repo.ping(settings.modelName)) {
                is AiResult.Success -> AiStatus.Connected
                is AiResult.Failure -> AiStatus.Failed(r.message)
            }
        }
    }

    override fun onCleared() { speech.release() }
}
