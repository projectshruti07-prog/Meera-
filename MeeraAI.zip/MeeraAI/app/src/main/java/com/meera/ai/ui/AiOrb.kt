package com.meera.ai.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.meera.ai.data.OrbState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** Animated neon orb. Idle = slow breathing, Listening = cyan ripples, Thinking = fast spinning arcs, Speaking = pink pulses. */
@Composable
fun AiOrb(state: OrbState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    val c1 by animateColorAsState(
        when (state) {
            OrbState.Idle -> Neon.Purple
            OrbState.Listening -> Neon.Cyan
            OrbState.Thinking -> Neon.Purple
            OrbState.Speaking -> Neon.Pink
        }, tween(500), label = "c1",
    )
    val c2 by animateColorAsState(
        when (state) {
            OrbState.Idle -> Neon.Pink
            OrbState.Listening -> Neon.Purple
            OrbState.Thinking -> Neon.Cyan
            OrbState.Speaking -> Neon.Cyan
        }, tween(500), label = "c2",
    )

    Canvas(modifier) {
        val center = Offset(size.width / 2, size.height / 2)
        val base = min(size.width, size.height) / 2 * 0.52f
        val pulse = when (state) {
            OrbState.Idle -> 0.03f * sin(t)
            OrbState.Listening -> 0.05f * sin(t * 3)
            OrbState.Thinking -> 0.03f * sin(t * 2)
            OrbState.Speaking -> 0.08f * abs(sin(t * 4)) + 0.02f * sin(t * 7)
        }
        val r = base * (1f + pulse)

        // outer glow
        drawCircle(
            Brush.radialGradient(listOf(c1.copy(alpha = 0.45f), Color.Transparent), center, r * 1.9f),
            radius = r * 1.9f, center = center,
        )
        // ripples while listening
        if (state == OrbState.Listening) {
            for (i in 0..2) {
                val p = ((t / (2 * PI).toFloat()) + i / 3f) % 1f
                drawCircle(
                    c1.copy(alpha = (1f - p) * 0.55f),
                    radius = r * (1f + p * 0.8f), center = center, style = Stroke(width = 3f),
                )
            }
        }
        // sphere
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.9f), c2, c1, Color(0xFF12002B)),
                center = center - Offset(r * 0.25f, r * 0.25f), radius = r * 1.3f,
            ),
            radius = r, center = center,
        )
        // orbiting rings
        val spin = when (state) {
            OrbState.Thinking -> 4f
            OrbState.Listening -> 2f
            else -> 1f
        }
        val ringR = r * 1.22f
        val tl = center - Offset(ringR, ringR)
        val sz = Size(ringR * 2, ringR * 2)
        rotate(degrees = t * 180f / PI.toFloat() * spin, pivot = center) {
            drawArc(c2, 0f, 90f, false, tl, sz, style = Stroke(width = 5f))
            drawArc(c1, 180f, 60f, false, tl, sz, style = Stroke(width = 3f))
        }
        val r2 = r * 1.4f
        rotate(degrees = -t * 180f / PI.toFloat() * spin, pivot = center) {
            drawArc(Neon.Pink.copy(alpha = 0.8f), 40f, 50f, false, center - Offset(r2, r2), Size(r2 * 2, r2 * 2), style = Stroke(width = 3f))
        }
    }
}
