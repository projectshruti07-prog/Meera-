package com.meera.ai.data

/** English defaults. Hindi/Bengali override the main UI strings; the rest fall back to English. */
data class UiText(
    val greeting: String = "Hi, I'm Meera. How can I help you today?",
    val askHint: String = "Ask Meera anything…",
    val navHome: String = "Home",
    val navChat: String = "Chat",
    val navVoice: String = "Voice",
    val navCode: String = "Code",
    val navSettings: String = "Settings",
    val qaYoutube: String = "Open YouTube",
    val qaApps: String = "Open Apps",
    val qaCoding: String = "Coding Help",
    val qaSettings: String = "Settings",
    val stateIdle: String = "Ready",
    val stateListening: String = "Listening…",
    val stateThinking: String = "Thinking…",
    val stateSpeaking: String = "Speaking…",
    val emptyChatTitle: String = "Start a conversation",
    val emptyChatBody: String = "Type a message or try one of these:",
    val send: String = "Send",
    val copy: String = "Copy",
    val copied: String = "Copied",
    val retry: String = "Retry",
    val clear: String = "Clear",
    val stopSpeaking: String = "Stop speaking",
    val tapToSpeak: String = "Tap the mic to speak",
    val tapToStop: String = "Tap to finish",
    val micDeniedMsg: String = "Microphone permission was denied. You can still type to Meera, or allow the microphone in app settings.",
    val openAppSettings: String = "App settings",
    val openChat: String = "Open chat",
    val confirmTitle: String = "Please confirm",
    val confirmYes: String = "Yes, do it",
    val confirmNo: String = "Cancel",
    val chooseApp: String = "Choose an app",
    val searchApps: String = "Search apps",
    val settingsTitle: String = "Settings",
    val aiSection: String = "AI connection",
    val connection: String = "Connection status",
    val testConnection: String = "Test connection",
    val connected: String = "Connected",
    val langSection: String = "Language",
    val speechSection: String = "Speech",
    val speakReplies: String = "Speak replies aloud",
    val speechRate: String = "Speech speed",
    val testVoice: String = "Test voice",
    val codeTitle: String = "Coding Mode",
    val codeHint: String = "Ask a programming question…",
    val aboutTitle: String = "About & limitations",
)

object L10n {
    private val En = UiText()
    private val Hi = En.copy(
        greeting = "नमस्ते, मैं मीरा हूँ। आज मैं आपकी क्या मदद कर सकती हूँ?",
        askHint = "मीरा से कुछ भी पूछें…",
        navHome = "होम", navChat = "चैट", navVoice = "आवाज़", navCode = "कोड", navSettings = "सेटिंग्स",
        qaYoutube = "YouTube खोलें", qaApps = "ऐप्स खोलें", qaCoding = "कोडिंग मदद", qaSettings = "सेटिंग्स",
        stateIdle = "तैयार", stateListening = "सुन रही हूँ…", stateThinking = "सोच रही हूँ…", stateSpeaking = "बोल रही हूँ…",
        emptyChatTitle = "बातचीत शुरू करें", send = "भेजें", copy = "कॉपी", copied = "कॉपी हुआ",
        retry = "फिर कोशिश करें", clear = "साफ़ करें", stopSpeaking = "बोलना रोकें",
        tapToSpeak = "बोलने के लिए माइक दबाएँ", tapToStop = "रोकने के लिए दबाएँ",
        micDeniedMsg = "माइक्रोफ़ोन की अनुमति नहीं मिली। आप टाइप कर सकते हैं, या ऐप सेटिंग्स में अनुमति दें।",
        openAppSettings = "ऐप सेटिंग्स", confirmTitle = "कृपया पुष्टि करें", confirmYes = "हाँ", confirmNo = "रद्द करें",
        chooseApp = "ऐप चुनें", searchApps = "ऐप खोजें", settingsTitle = "सेटिंग्स", aiSection = "AI कनेक्शन",
        connection = "कनेक्शन स्थिति", testConnection = "कनेक्शन जाँचें", connected = "जुड़ा हुआ",
        langSection = "भाषा", speechSection = "आवाज़", speakReplies = "जवाब बोलकर सुनाएँ",
        speechRate = "बोलने की गति", testVoice = "आवाज़ जाँचें", codeTitle = "कोडिंग मोड",
        codeHint = "प्रोग्रामिंग के बारे में पूछें…",
    )
    private val Bn = En.copy(
        greeting = "হাই, আমি মীরা। আজ আমি আপনাকে কীভাবে সাহায্য করতে পারি?",
        askHint = "মীরাকে যেকোনো কিছু জিজ্ঞাসা করুন…",
        navHome = "হোম", navChat = "চ্যাট", navVoice = "ভয়েস", navCode = "কোড", navSettings = "সেটিংস",
        qaYoutube = "YouTube খুলুন", qaApps = "অ্যাপ খুলুন", qaCoding = "কোডিং সাহায্য", qaSettings = "সেটিংস",
        stateIdle = "প্রস্তুত", stateListening = "শুনছি…", stateThinking = "ভাবছি…", stateSpeaking = "বলছি…",
        emptyChatTitle = "কথোপকথন শুরু করুন", send = "পাঠান", copy = "কপি", copied = "কপি হয়েছে",
        retry = "আবার চেষ্টা করুন", clear = "মুছুন", stopSpeaking = "কথা থামান",
        tapToSpeak = "বলতে মাইকে ট্যাপ করুন", tapToStop = "শেষ করতে ট্যাপ করুন",
        micDeniedMsg = "মাইক্রোফোনের অনুমতি দেওয়া হয়নি। আপনি টাইপ করতে পারেন, অথবা অ্যাপ সেটিংসে অনুমতি দিন।",
        openAppSettings = "অ্যাপ সেটিংস", confirmTitle = "নিশ্চিত করুন", confirmYes = "হ্যাঁ", confirmNo = "বাতিল",
        chooseApp = "অ্যাপ বেছে নিন", searchApps = "অ্যাপ খুঁজুন", settingsTitle = "সেটিংস", aiSection = "AI সংযোগ",
        connection = "সংযোগের অবস্থা", testConnection = "সংযোগ পরীক্ষা করুন", connected = "সংযুক্ত",
        langSection = "ভাষা", speechSection = "কণ্ঠস্বর", speakReplies = "উত্তর জোরে পড়ুন",
        speechRate = "কথা বলার গতি", testVoice = "ভয়েস পরীক্ষা", codeTitle = "কোডিং মোড",
        codeHint = "প্রোগ্রামিং নিয়ে জিজ্ঞাসা করুন…",
    )

    fun of(l: AppLanguage): UiText = when (l) {
        AppLanguage.English -> En
        AppLanguage.Hindi -> Hi
        AppLanguage.Bengali -> Bn
    }
}
