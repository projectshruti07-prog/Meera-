package com.meera.ai.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.meera.ai.data.AppLanguage

/** Wraps Android SpeechRecognizer (speech-to-text) and TextToSpeech. Call from the main thread. */
class SpeechController(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    var onSpeaking: (Boolean) -> Unit = {}

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { onSpeaking(true) } }
                    override fun onDone(utteranceId: String?) { main.post { onSpeaking(false) } }
                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onError(utteranceId: String?) { main.post { onSpeaking(false) } }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { onSpeaking(false) } }
                })
            }
        }
    }

    /** Returns an error message, or null on success. */
    fun speak(text: String, lang: AppLanguage, rate: Float): String? {
        val engine = tts
        if (engine == null || !ttsReady) return "Text-to-speech isn't ready (or no engine is installed on this device)."
        val r = engine.setLanguage(lang.locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            return "This device has no ${lang.label} voice. Install it in system settings → Text-to-speech."
        }
        engine.setSpeechRate(rate)
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " ").replace(Regex("[*#`_]"), "").trim().take(3900)
        if (clean.isBlank()) return null
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "meera")
        return null
    }

    fun stopSpeaking() {
        tts?.stop()
        main.post { onSpeaking(false) }
    }

    fun startListening(
        lang: AppLanguage,
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit,
        whenError: (String) -> Unit,
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            whenError("Speech recognition isn't available on this device. Please type instead.")
            return
        }
        cancelListening()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                main.post { cancelListening() }
                if (t.isNullOrBlank()) whenError("I didn't catch that. Try again or type your message.") else onResult(t)
            }
            override fun onError(error: Int) {
                main.post { cancelListening() }
                if (error == SpeechRecognizer.ERROR_CLIENT) return
                whenError(describe(error))
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.speechTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizer = r
        r.startListening(intent)
    }

    fun stopListening() { recognizer?.stopListening() }

    fun cancelListening() {
        recognizer?.destroy()
        recognizer = null
    }

    fun release() {
        cancelListening()
        tts?.stop(); tts?.shutdown(); tts = null
    }

    private fun describe(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything. Tap the mic and try again."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
            "Speech recognition needs a network connection right now."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again in a moment."
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
            "This language isn't available for speech recognition on your device."
        else -> "Speech recognition failed (code $code). You can type instead."
    }
}
