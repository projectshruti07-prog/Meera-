package com.meera.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Neon {
    val Bg = Color(0xFF07040F)
    val Surface = Color(0xFF130B26)
    val SurfaceHi = Color(0xFF1D1237)
    val Pink = Color(0xFFFF3DDC)
    val Purple = Color(0xFF9D5CFF)
    val Cyan = Color(0xFF27E6FF)
    val Text = Color(0xFFF3EDFF)
    val Muted = Color(0xFF9C90B8)
    val Error = Color(0xFFFF5C7A)
    val Ok = Color(0xFF4DFFB0)
    val gradient = Brush.horizontalGradient(listOf(Pink, Purple, Cyan))
}

@Composable
fun MeeraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.Cyan, onPrimary = Color(0xFF00212A),
            secondary = Neon.Pink, tertiary = Neon.Purple,
            background = Neon.Bg, onBackground = Neon.Text,
            surface = Neon.Surface, onSurface = Neon.Text,
            surfaceVariant = Neon.SurfaceHi, onSurfaceVariant = Neon.Muted,
            error = Neon.Error, outline = Neon.Purple,
        ),
        typography = Typography(),
        content = content,
    )
}
