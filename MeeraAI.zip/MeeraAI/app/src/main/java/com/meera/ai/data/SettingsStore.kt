package com.meera.ai.data

import android.content.Context

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("meera_prefs", Context.MODE_PRIVATE)

    fun load(): Settings = Settings(
        language = AppLanguage.entries.firstOrNull { it.code == p.getString("lang", deviceLang()) } ?: AppLanguage.English,
        speakReplies = p.getBoolean("speak", true),
        speechRate = p.getFloat("rate", 1f),
        modelName = p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL,
    )

    /** First launch: use the phone's language if it is Hindi or Bengali, otherwise English. */
    private fun deviceLang(): String = java.util.Locale.getDefault().language.let { if (it == "hi" || it == "bn") it else "en" }

    fun save(s: Settings) {
        p.edit()
            .putString("lang", s.language.code)
            .putBoolean("speak", s.speakReplies)
            .putFloat("rate", s.speechRate)
            .putString("model", s.modelName)
            .apply()
    }
}
