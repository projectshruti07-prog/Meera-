# Meera AI (Kotlin + Jetpack Compose)

Futuristic neon Android assistant: Home, Chat, Voice, Coding Mode, Settings. Gemini via **Firebase AI Logic**
(Gemini Developer API) with **App Check**. No API key exists anywhere in this source.

> **Status:** written but NOT yet compiled or run by the author's tooling (no Android SDK was available).
> Expect to fix a few small compile errors on the first build. Paste them to Claude and they can be fixed quickly.

## Quick start on a phone (GitHub)
1. github.com → New repository (Private). Upload the unzipped project files (Add file → Upload files; keep the folder structure, including the hidden `.github` folder).
2. Actions tab → enable workflows → **Build debug APK** → Run workflow.
3. Wait ~5–8 minutes. Green tick → open the run → Artifacts → `meera-ai-debug-apk` → download → unzip → install.
4. Red cross → open the run → the **Summary** shows the compile errors. Send them to Claude to fix.
Versions checked against Firebase release notes (BoM 34.17.0, `gemini-2.5-flash`) but the project is still uncompiled.

## Voice commands (English / Hindi / Bengali / Hinglish)
`open youtube` · `youtube kholo` · `यूट्यूब खोलो` · `ইউটিউব খোলো` · `play arijit songs on youtube` · `youtube par lofi chalao` · `whatsapp kholo`

## Project tree
```
MeeraAI/
├─ settings.gradle.kts · build.gradle.kts · gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties      (wrapper JAR is generated, see Build)
├─ .github/workflows/build.yml                   (cloud APK build, no PC needed)
└─ app/
   ├─ build.gradle.kts · proguard-rules.pro
   ├─ google-services.json                       ← YOU add this (never committed)
   └─ src/
      ├─ main/AndroidManifest.xml
      ├─ main/res/ (theme, icon, strings)
      ├─ main/java/com/meera/ai/
      │  ├─ MainActivity.kt · MeeraApp.kt · MeeraViewModel.kt
      │  ├─ data/  Models.kt · SettingsStore.kt · L10n.kt (EN/HI/BN)
      │  ├─ ai/    GeminiRepository.kt · FirebaseSetup.kt · Commands.kt · SpeechController.kt
      │  └─ ui/    Theme.kt · AiOrb.kt · Components.kt · Screens.kt · Navigation.kt
      ├─ debug/…/AppCheckInstaller.kt              (debug App Check provider)
      └─ release/…/AppCheckInstaller.kt            (Play Integrity provider)
```

## Firebase + Gemini setup
1. Go to https://console.firebase.google.com → **Add project** (Spark/free plan is fine to start).
2. **Project settings → Add app → Android**. Package name must be exactly `com.meera.ai`. Download `google-services.json` and put it in `app/`. Without this file the app still runs but shows "Not configured" and Gemini is disabled.
3. In the console open **Build → AI Logic → Get started**, choose **Gemini Developer API**, and enable it. Firebase creates and keeps the Gemini key server-side; it is never in your APK.
4. **App Check** (Build → App Check):
   - Release: register the Android app with **Play Integrity** (needs the app on Google Play + your signing SHA-256; get it with `gradle signingReport`).
   - Debug: debug builds use the debug provider. Run the app once and read the "debug secret" from Logcat (tag `DebugAppCheckProvider`), then add it under App Check → Apps → ⋮ → Manage debug tokens. Needs a computer with Logcat/adb.
   - **Beginner path:** leave App Check *unenforced* at first (the default). Requests work. Turn enforcement on for AI Logic only once Play Integrity / debug tokens are registered, otherwise requests will be rejected.
5. Set per-user rate limits and a budget alert in the console to control quota/cost.
6. Model: default `gemini-2.5-flash`. Models get retired, so if you see "model not found", change the model name in Meera's Settings. Check current names in the Firebase AI Logic docs.

Then in the app: **Settings → Test connection**.

## Build a debug APK
**A. Android Studio (PC/Mac/Linux):** open the folder, let Gradle sync, **Build → Build APK(s)**. Output: `app/build/outputs/apk/debug/app-debug.apk`.
Or from terminal: `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.

**B. Phone-only (recommended): GitHub Actions.**
1. Create a free GitHub repo, upload this folder (GitHub mobile site works).
2. Optional: Settings → Secrets → add `GOOGLE_SERVICES_JSON_BASE64` (your google-services.json, base64-encoded) so the APK has Firebase.
3. Actions tab → "Build debug APK" → Run workflow. Download `meera-ai-debug-apk` from the run, unzip, install the APK (allow "install unknown apps").
Note: do not commit google-services.json to a public repo; use the secret.

## Termux (further development on the phone)
Editing and git in Termux work well; **building** Android apps inside Termux is advanced and fragile (the official Android build tools ship x86 binaries; you must substitute ARM `aapt2`). Easiest workflow: edit in Termux, push to GitHub, let Actions build.
```
pkg update && pkg upgrade
pkg install git nano openjdk-17
termux-setup-storage
git clone https://github.com/YOURNAME/MeeraAI.git && cd MeeraAI
nano app/src/main/java/com/meera/ai/ui/Theme.kt     # edit
git add -A && git commit -m "tweak" && git push      # triggers the cloud build
```
(To push you need a GitHub personal access token as the password.)

## What works / doesn't
- Opens YouTube, searches YouTube, opens installed apps. Typed/spoken commands ask for confirmation; picking an app from the list does not (you chose it explicitly).
- Cannot control inside other apps, send SMS, place calls, etc.; not implemented, and Android requires special permissions (e.g. accessibility service) that Meera doesn't use.
- Voice commands parse English only; chat/voice conversation works in English, Hindi, Bengali if your phone has the speech/TTS language data.
- Hindi/Bengali translations cover the main UI; long help text and error messages are English.
